﻿select	
	sum(md.cantidad) as Salidas
from 
	movimientos m
inner join 	
	movimientos_detalles as md
on 
	m.mov_id = md.movimiento_id
where 
	m.tipo_movimiento = 'Salida' 
group by 
	md.articulo_id, m.fecha
order by
	md.articulo_id 