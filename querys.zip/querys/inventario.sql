﻿Select m.articulo_id, sum(m.cantidad) as entradas, 0 as salidas
from movimientos m
inner join articulos a on m.articulo_id = a.articulo_id
where m.tipo_movimiento = 'Entrada'
group by m.articulo_id
union 
Select m.articulo_id, 0 as entradas, sum(m.cantidad) as salidas
from movimientos m
inner join articulos a on m.articulo_id = a.articulo_id
where m.tipo_movimiento = 'Salida'
group by m.articulo_id
order by 1


	 


