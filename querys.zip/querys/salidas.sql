﻿Create table salidas_temp as
Select 
	dd.articulo_id,
	sum(dd.cantidad) as Salidas
from 
	despachos d
left join 
	despacho_detalles dd
on 
	d.despacho_id = dd.despacho_id
where 
	d.emision between '2010-01-01' and '2011-01-31'
group by 
	dd.articulo_id
order by
	dd.articulo_id
	 


