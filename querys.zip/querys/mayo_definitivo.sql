﻿create table inventario_mayo_2011 as
select 
	codigo,
	ar.nombre,
	costo,
	existencia_anterior,
	entradas,
	coalesce(salidas,0.000) as salidas,
	coalesce(entradas, 0.000) - coalesce(salidas,0.00) as existencia,
	coalesce(entrada_bs, 0.00) as entrada_bs,
	coalesce(salida_bs, 0.00) as salida_bs,
	coalesce(entrada_bs, 0.00)- coalesce(salida_bs, 0.00) as existencia_bs
from mayo
left join articulos ar
	on codigo = ar.articulo_id