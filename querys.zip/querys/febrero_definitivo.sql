﻿select 

	f.articulo_id as articulo,
	a.nombre as descripcion,
	f.costo,
	COALESCE(f.existencia_anterior,0.00) as existencia_anterior,
	f.entradas,
	COALESCE(f.salidas,0.00) as salidas,
	COALESCE(f.existencia,0.00) as existencia,
	COALESCE(f.entrada_bs,0.00) as entradas_bs,
	COALESCE(f.salidas_bs,0.00) as salidas_bs,
	COALESCE(f.existencia_bs,0.00) as existencia_bs
from
	febrero f
inner join
	articulos a
on 
	a.articulo_id = f.articulo_id