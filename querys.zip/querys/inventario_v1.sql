﻿
select 	md1.articulo_id as codigo, 
	a.costo_actual as Costo,
	sum(md1.cantidad) as Entradas, 
	(select sum(md2.cantidad) 
	from 
		movimientos m2
	inner join 	
		movimientos_detalles as md2
	on 
		m2.mov_id = md2.movimiento_id
	where 
		m2.tipo_movimiento = 'Salida' and md2.articulo_id = md1.articulo_id
		and m2.fecha >= '2011-01-01' and m2.fecha <= '2011-05-19'
	group by md2.articulo_id
	 
	order by
		md2.articulo_id) as Salidas, 
	(sum(md1.cantidad)-(select sum(md2.cantidad) 
				from 
					movimientos m2
				inner join 	
					movimientos_detalles as md2
				on 
					m2.mov_id = md2.movimiento_id
				where 
					m2.tipo_movimiento = 'Salida' and md2.articulo_id = md1.articulo_id
					and m2.fecha >= '2011-01-01' and m2.fecha <= '2011-05-19'
				group by md2.articulo_id
				 
				order by
					md2.articulo_id)) as Existencia,
				(sum(md1.cantidad) * a.costo_actual) as Entrada_Bs,
				((select sum(md2.cantidad) 
				from 
					movimientos m2
				inner join 	
					movimientos_detalles as md2
				on 
					m2.mov_id = md2.movimiento_id
				where 
					m2.tipo_movimiento = 'Salida' and md2.articulo_id = md1.articulo_id
					and m2.fecha >= '2011-01-01' and m2.fecha <= '2011-05-19'
				group by md2.articulo_id
				 
				order by
					md2.articulo_id) * a.costo_actual) as Salidas_Bs,
				(sum(md1.cantidad)-(select sum(md2.cantidad) 
				from 
					movimientos m2
				inner join 	
					movimientos_detalles as md2
				on 
					m2.mov_id = md2.movimiento_id
				where 
					m2.tipo_movimiento = 'Salida' and md2.articulo_id = md1.articulo_id and
					m2.fecha >= '2011-01-01' and m2.fecha <= '2011-05-19'
				group by md2.articulo_id
				 
				order by
					md2.articulo_id)) * a.costo_actual as Existencia_Bs
from 
	movimientos m1
inner join 	
	movimientos_detalles as md1
on 
	m1.mov_id = md1.movimiento_id
inner join 
	articulos a
on 
	md1.articulo_id = a.articulo_id
where 
	m1.tipo_movimiento = 'Entrada' and
	m1.fecha >= '2011-01-01' and m1.fecha <= '2011-05-19'
Group by 
	codigo, a.costo_actual
order by 
	codigo



