﻿select 

	e.articulo_id as articulo,
	a.nombre as descripcion,
	e.costo,
	COALESCE(e.existencia_anterior,0.00) as existencia_anterior,
	e.entradas,
	COALESCE(e.salidas, 0.00) as salidas,
	(e.entradas - e.salidas) as existencia,
	COALESCE(e.entrada_bs,0.00) as entradas_bs,
	COALESCE(e.salidas_bs,0.00) as salidas_bs,
	COALESCE(e.existencia_bs,0.00) as existencia_bs
from
	enero e
inner join
	articulos a
on 
	a.articulo_id = e.articulo_id