﻿create table inventario_julio_2011 as
select 
	jul.codigo,
	ar.nombre,
	coalesce(jul.costo, 0.00) as costo,
	coalesce(m.existencia, 0.000) + (coalesce(jun.entradas, 0.000)- coalesce(jun.salidas, 0.000)) as existencia_anterior,
	coalesce(jul.entradas, 0.000) as entradas,
	coalesce(jul.salidas, 0.000) as salidas,
	coalesce(m.existencia, 0.000) + (coalesce(jun.entradas, 0.000)- coalesce(jun.salidas, 0.000)) + (coalesce(jul.entradas, 0.000)- coalesce(jul.salidas, 0.000)) as existencia,
	coalesce(jul.entrada_bs, 0.00) as entrada_bs,
	round(coalesce(jul.salida_bs, 0.00), 2) as salida_bs,
	round(coalesce(m.existencia, 0.000)+(coalesce(jun.entradas, 0.000)- coalesce(jun.salidas, 0.000)) + (coalesce(jul.entradas, 0.000)- coalesce(jul.salidas, 0.000)))* coalesce(jul.costo, 0.00) as existencia_bs
from julio jul
left join junio jun
	on jun.codigo = jul.codigo
left join mayo m
	on jun.codigo = m.codigo
left join articulos ar
	on jul.codigo = ar.articulo_id