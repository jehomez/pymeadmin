﻿Select  
	cd.articulo_id,
	
	sum(cd.costo) as costo,
	(sum(cd.cantidad)-(select sum(dd.cantidad) 
				from 
					despachos d
				left join 	
					despacho_detalles as dd
				on 
					d.despacho_id = dd.despacho_id
				where 
					dd.articulo_id = cd.articulo_id
					and d.emision between '2010-12-01' and '2010-12-31'
				group by 
					dd.articulo_id
				order by
					dd.articulo_id)) as Existencia_Anterior,
	sum(cd.cantidad) as Entradas,
	(select sum(dd.cantidad) 
	from 
		despachos d
	left join 	
		despacho_detalles as dd
	on 
		d.despacho_id = dd.despacho_id
	where 
		dd.articulo_id = cd.articulo_id
		and d.emision between '2011-01-01' and '2011-01-31'
	group by 
		dd.articulo_id
	order by
		dd.articulo_id) as Salidas, 
	(sum(cd.cantidad)-(select sum(dd.cantidad) 
				from 
					despachos d
				left join 	
					despacho_detalles as dd
				on 
					d.despacho_id = dd.despacho_id
				where 
					dd.articulo_id = cd.articulo_id
					and d.emision between '2011-01-01' and '2011-01-31'
				group by 
					dd.articulo_id
				order by
					dd.articulo_id)) as Existencia,
				(sum(cd.cantidad) * cd.costo) as Entrada_Bs,
				((select sum(md.cantidad) 
				from 
					movimientos m
				inner join 	
					movimientos_detalles as md
				on 
					m.mov_id = md.movimiento_id
				where 
					m.tipo_movimiento = 'Salida' and md.articulo_id = cd.articulo_id
					and m.fecha >= '2011-01-01' and m.fecha <= '2011-05-01'
				group by md.articulo_id
				 
				order by
					md.articulo_id) * cd.costo) as Salidas_Bs,
				(sum(cd.cantidad)-(select sum(md.cantidad) 
				from 
					movimientos m
				inner join 	
					movimientos_detalles as md
				on 
					m.mov_id = md.movimiento_id
				where 
					m.tipo_movimiento = 'Salida' and md.articulo_id = cd.articulo_id and
					m.fecha >= '2011-01-01' and m.fecha <= '2011-05-01'
				group by md.articulo_id
				 
				order by
					md.articulo_id)) * cd.costo as Existencia_Bs
	
from 
	compras c
inner join 
	compras_detalles cd
on	
	c.compra_id = cd.compra_id
where 
	c.emision >= '2011-04-01' and emision <= '2011-04-30'
group by
	cd.articulo_id, cd.costo
order by 
	cd.articulo_id



