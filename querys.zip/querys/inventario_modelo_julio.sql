﻿-- drop table julio;
create table julio as
Select  
	cd.articulo_id as codigo,
	round(avg(cd.costo),2) as costo,
	coalesce(round((sum(cd.cantidad)-0),2)) as Existencia_Anterior,
	sum(cd.cantidad) as Entradas,
	(select sum(dd.cantidad)
	from 
		despachos d
	left join 	
		despacho_detalles as dd
	on 
		d.despacho_id = dd.despacho_id
	where 
		dd.articulo_id = cd.articulo_id
		and d.emision between '2011-07-01' and '2011-07-30'
	group by 
		dd.articulo_id
	order by
		dd.articulo_id) as Salidas, 
	sum(cd.cantidad)-(select coalesce(sum(dd.cantidad),0) 
				from 
					despachos d
				left join 	
					despacho_detalles as dd
				on 
					d.despacho_id = dd.despacho_id
				where 
					dd.articulo_id = cd.articulo_id
					and d.emision between '2011-07-01' and '2011-07-30'
				group by 
					dd.articulo_id
				order by
					dd.articulo_id) as Existencia,
				round(sum(cd.cantidad) * avg(cd.costo),2) as Entrada_Bs,
				(select sum(dd.cantidad) 
				from 
					despachos d
				left join 	
					despacho_detalles as dd
				on 
					d.despacho_id = dd.despacho_id
				where 
					dd.articulo_id = cd.articulo_id
					and d.emision between '2011-07-01' and '2011-07-30'
				group by 
					dd.articulo_id
				order by
					dd.articulo_id) * round(avg(cd.costo),2) as Salida_Bs,
				(sum(cd.cantidad)-(select sum(dd.cantidad) 
				from 
					despachos d
				left join 	
					despacho_detalles as dd
				on 
					d.despacho_id = dd.despacho_id
				where 
					dd.articulo_id = cd.articulo_id
					and d.emision between '2011-07-01' and '2011-07-30'
				group by 
					dd.articulo_id
				order by
					dd.articulo_id)) * avg(cd.costo) as Existencia_Bs
	
from 
	compras c
left join 
	compras_detalles cd
on	
	c.compra_id = cd.compra_id
where 
	c.emision between '2011-07-01' and '2011-07-30'
group by
	cd.articulo_id
order by 
	cd.articulo_id
