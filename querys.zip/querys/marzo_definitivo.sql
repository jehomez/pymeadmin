﻿select 

	m.articulo_id as articulo,
	a.nombre as descripcion,
	m.costo,
	COALESCE(m.existencia_anterior,0.00) as existencia_anterior,
	m.entradas,
	COALESCE(m.salidas,0.00) as salidas,
	COALESCE(m.existencia,0.00) as existencia,
	COALESCE(m.entrada_bs,0.00) as entradas_bs,
	COALESCE(m.salidas_bs,0.00) as salidas_bs,
	COALESCE(m.existencia_bs,0.00) as existencia_bs
from
	marzo m
inner join
	articulos a
on 
	a.articulo_id = m.articulo_id