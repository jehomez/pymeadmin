﻿
select
	ar.articulo_id as codigo, 
	an.existencia_diciembre as existencia_anterior,
	en.entradas,
	sa.salidas,
	ex.existencias
from
	articulos ar
inner join
	existencia_diciembre an
on
	ar.articulo_id = an.articulo_id
inner join
	entradas_temp en
on 
	ar.articulo_id = en.articulo_id

inner join
	salidas_temp sa
on 
	ar.articulo_id = sa.articulo_id
inner join
	existencia ex
on 
	ar.articulo_id = ex.articulo_id

