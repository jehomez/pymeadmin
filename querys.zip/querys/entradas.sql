﻿Create table Entradas_temp as
Select 
	cd.articulo_id,
	sum(cd.cantidad) as entradas
from 
	compras c
left join 
	compras_detalles cd
on 
	c.compra_id = cd.compra_id
where 
	c.emision between '2010-01-01' and '2011-01-31'
group by 
	cd.articulo_id
order by
	cd.articulo_id
