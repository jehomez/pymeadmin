﻿create table inventario_junio_2011 as 
select 
	j.codigo,
	ar.nombre,
	coalesce(j.costo, 0.00) as costo,
	coalesce(m.existencia, 0.000) as existencia_anterior,
	coalesce(j.entradas, 0.000) as entradas,
	coalesce(j.salidas, 0.000) as salidas,
	coalesce(m.existencia, 0.000) + (coalesce(j.entradas, 0.000)-coalesce(j.salidas, 0.000)) as existencia,
	coalesce(j.entrada_bs, 0.00) as entrada_bs,
	round(coalesce(j.salida_bs, 0.00),2) as salida_bs,
	round(coalesce(m.existencia, 0.000) + (coalesce(j.entradas, 0.000)-coalesce(j.salidas, 0.000)))* coalesce(j.costo, 0.00) as existencia_bs
from junio j
left join mayo m
	on m.codigo = j.codigo
left join articulos ar
	on j.codigo = ar.articulo_id