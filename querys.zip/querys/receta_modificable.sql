﻿CREATE FUNCTION obtener_receta(numeric, numeric) RETURN TEXT AS '
declare
	
SELECT
    rd.cantidad/4 as cantidad,
    rd.articulo_id,
    ar.nombre,
    ar.costo_actual/4 as costo_actual,
    '@',
    ar.iva_compra,
    round((ar.iva_compra/100) * (rd.total_neto/4),2) as monto_iva_compra,
    rd.total_neto/4 as total_neto
FROM
    recetas_detalles rd
INNER JOIN
    articulos ar
ON
    rd.articulo_id = ar.articulo_id
INNER JOIN
    recetas r
ON
    rd.receta_id = r.receta_id