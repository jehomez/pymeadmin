﻿create table existencia as
Select 
	e.articulo_id, (e.entradas - s.salidas ) as existencia
from 
	entradas_temp e
inner join
	salidas_temp s
on
	e.articulo_id = s.articulo_id
group by
	e.articulo_id