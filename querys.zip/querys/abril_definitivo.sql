﻿select 

	ab.articulo_id as articulo,
	a.nombre as descripcion,
	ab.costo,
	COALESCE(ab.existencia_anterior,0.00) as existencia_anterior,
	ab.entradas,
	COALESCE(ab.salidas,0.00) as salidas,
	COALESCE(ab.existencia,0.00) as existencia,
	COALESCE(ab.entrada_bs,0.00) as entradas_bs,
	COALESCE(ab.salidas_bs,0.00) as salidas_bs,
	COALESCE(ab.existencia_bs,0.00) as existencia_bs
from
	abril ab
inner join
	articulos a
on 
	a.articulo_id = ab.articulo_id